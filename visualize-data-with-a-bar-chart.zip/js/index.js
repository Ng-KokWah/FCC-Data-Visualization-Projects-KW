const dataset = [];
const w = 1780;
const h = 530;
const padding = 60;

const svg=d3.select("body")
.append("svg")
.attr("width", w)
.attr("height", h);
 $.getJSON('https://raw.githubusercontent.com/freeCodeCamp/ProjectReferenceData/master/GDP-data.json', function(data) {
   //data.data[0][0] gives me the first date
   //data.data[0][1] gives me the first value from that date
      for(var i=0; i<data.data.length; i++) {
          dataset.push([JSON.stringify(data.data[i][0]).replace(/['"]+/g, ''), parseFloat(JSON.stringify(data.data[i][1]))]);
      }
   
        svg.selectAll("rect")
        .data(dataset)
        .enter()
      .append("rect")
      .attr("x", (d,i) => {
        return 60 + i  * 6;
      })
  .attr("y", (d) => (h - (d[1]/40) -60))
  .attr("width", 5)
  .attr("height", (d) => (d[1]/40) + "px")
   .attr('data-date', (d) => d[0])
   .attr('data-gdp', (d) => d[1])
   .on("mouseover", function(d) {
    d3.select(this).attr("width", 7).style("fill", "red");
  })                  
  .on("mouseout", function(d) {
    d3.select(this).attr("width", 5).style("fill", "blue");
  });

svg.selectAll("rect")
  .attr("class", "bar")
   .append("title")
  .text((d) => "Date Time: " + d[0] + "\r\nGDP: $" + d[1] + " Billion")
  .attr("id", "tooltip")
   .attr('data-date', (d) => d[0])
   .attr('data-gdp', (d) => d[1]);
   
   const xScale = d3.scaleTime()
.domain([new Date(1947, 01, 01), new Date(2015, 07, 01)])
.range([padding, w - padding]);

const yScale = d3.scaleLinear()
.domain([d3.min(dataset, (d) => d[1]), d3.max(dataset, (d) => d[1])])
.range([h - padding, padding]);

const xAxis = d3.axisBottom(xScale);
const yAxis = d3.axisLeft(yScale);

svg.append("g")
.attr("transform", "translate(0," + (h - padding) + ")")
.call(xAxis)
.attr("id", "x-axis");

svg.append("g")
.attr("transform", "translate(60,0)")
.call(yAxis)
.attr("id", "y-axis");
   
   svg.append("text")
    .attr("id", "x-axis-label")
   .attr("text-anchor", "end")
   .attr("x", w - 20)
   .attr("y", h-padding)
   .text("Year");
   
  svg.append("text")
    .attr("id", "y-axis-label")
   .attr("text-anchor", "end")
   .attr("y", 2)
   .attr("dy", ".75em")
   .attr("transform", "rotate(-90)")
   .text("Gross Domestic Product (in Billion) $");
    });