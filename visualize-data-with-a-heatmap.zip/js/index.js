const dataset = [];
const months = [];
const years = [];
var baseTemp = 0;
var marginsTRBL = {top: 30, right: 30, bottom: 30, left: 30};
const w = 1300;
const h = 450;
const padding = 60;
//green, yellow, orange, red
const colors = ['rgb(139, 244, 65)', 'rgb(244, 229, 65)', 'rgb(244, 158, 66)', 'rgb(244, 65, 65)', 'rgb(173, 25, 183)']

// append the svg object to the body of the page
const svg = d3.select("body")
.append("svg")
  .attr("width", w + marginsTRBL.left + marginsTRBL.right)
  .attr("height", h + marginsTRBL.top + marginsTRBL.bottom)
.append("g")
  .attr("transform",
        "translate(" + marginsTRBL.left + "," + marginsTRBL.top + ")");

 $.getJSON('https://raw.githubusercontent.com/freeCodeCamp/ProjectReferenceData/master/global-temperature.json', function(data) {
   baseTemp = data.baseTemperature;
   for(var i=0; i<data.monthlyVariance.length; i++) {
         //console.log(data.monthlyVariance[i].year); 
     var test = {};
     test.year = parseInt(JSON.stringify(data.monthlyVariance[i].year));
     test.month = parseInt(JSON.stringify(data.monthlyVariance[i].month));
     test.variance = parseFloat(JSON.stringify(data.monthlyVariance[i].variance));
     dataset.push(test);
     months.push(parseInt(JSON.stringify(data.monthlyVariance[i].month)));
     years.push(parseInt(JSON.stringify(data.monthlyVariance[i].year)));
      }
   
var x = d3.scaleLinear()
  .range([ 0, w ])
  .domain([d3.min(dataset, (d) => d.year), d3.max(dataset, (d) => d.year)]);

var y = d3.scaleLinear()
  .range([ h, 0 ])
  .domain([d3.min(dataset, (d) => d.month), d3.max(dataset, (d) => d.month)]);
   
svg.append("g")
  .attr("transform", "translate(0," + h + ")")
  .call(d3.axisBottom(x));
   
svg.append("g")
  .call(d3.axisLeft(y));

/*var colorScale = d3.scaleLinear()
  .range(["white", "#69b3a2"])
  .domain([d3.min(dataset, (d) => d.variance),d3.max(dataset, (d) => d.variance)]);*/
   /*var colorLow = 'green', colorMed = 'yellow', colorHigh = 'red';
   var colorScale = d3.scaleLinear()
     .domain([d3.min(dataset, (d) => d.variance), 0, d3.max(dataset, (d) => d.variance)])
     .range([colorLow, colorMed, colorHigh]);*/
   
   svg.append("text")
    .attr("id", "x-axis-label")
   .attr("text-anchor", "end")
   .attr("x", w + 30)
   .attr("y", h + 15)
   .text("Year")
   .style("fill", "blue");
   
  svg.append("text")
    .attr("id", "y-axis-label")
   .attr("text-anchor", "end")
   .attr("y", -33)
   .attr("dy", ".75em")
   .attr("transform", "rotate(-90)")
   .text("Month")
   .style("fill", "blue");
   
   var gridSize = 50,
    height = gridSize,
    width = gridSize,
    rectPad = 60;
   
   var minimum = d3.min(dataset, d => d.year);
   let boxWidth = (w-marginsTRBL.left-marginsTRBL.right) / (dataset.length/12);
  let boxHeight = (h-marginsTRBL.top-marginsTRBL.bottom)/12;
   svg.selectAll('rect')
      .data(dataset)
      .enter()
      .append('rect')
      .attr('width', boxWidth )
      .attr('height', boxHeight)
      .attr('x', (d, i) =>{
              var x = d.year - minimum;
              return x*boxWidth + marginsTRBL.left;
          })
      .attr('y', (d, i) => h -  (marginsTRBL.bottom + boxHeight) - (d.month-1)*boxHeight )
      .attr('fill', d => color(baseTemp + d.variance))
     .attr('class', 'cell')
   .attr('data-month', (d) => d.month)
   .attr('data-year', (d) => d.year)
   .attr('data-temp', (d) => baseTemp + d.variance)
      .append("title")
      .text((d) => "Year: " + d.year + "\r\nMonth: " + d.month + "\r\nTemperature Difference: " + (baseTemp + d.variance))
      .attr("id", "tooltip");
   
   //creating the legend
   var computedDiff = ["< 3", "< 5", "< 7", "< 9", "9 and Above"];
  var val = [2, 4, 6, 8, 10];
  var legend = d3.select("#legend").append("svg")
    .attr("class", "legend")
    .attr("width", 140)
    .attr("height", 200)
    .selectAll("g")
    .data(val)
    .enter()
    .append("g")
    .attr("transform", function(d, i) {
      return "translate(0," + i * 20 + ")";
    });

  legend.append("rect")
    .attr("width", 18)
    .attr("height", 18)
    .style("fill", color);

  legend.append("text")
    .data(computedDiff)
    .attr("x", 24)
    .attr("y", 9)
    .attr("dy", ".35em")
    .text(function(d) {
      return d;
    });
});

function color(value) {
  if(value < 3) {
    return colors[0];
  }
  else if(value < 5) {
    return colors[1];
  }
  else if(value < 7) {
    return colors[2];
  }
  else if(value < 9) {
    return colors[3];
  }
  else {
    return colors[4];
  }
}