A Pen created at CodePen.io. You can find this one at https://codepen.io/dragdest4/pen/RdLdKQ.

 