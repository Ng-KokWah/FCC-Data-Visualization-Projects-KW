const dataset = [];
const w = 1780;
const h = 500;
const padding = 60;

const svg=d3.select("body")
.append("svg")
.attr("width", w)
.attr("height", h);
 $.getJSON('https://raw.githubusercontent.com/freeCodeCamp/ProjectReferenceData/master/cyclist-data.json', function(data) {
    for(var i=0; i<data.length; i++) {   
 //Save the Time, Place, Seconds, Name, Year & Doping status     
  dataset.push([JSON.stringify(data[i].Time).replace(/['"]+/g, ''), JSON.stringify(data[i].Place).replace(/['"]+/g, ''), parseInt(data[i].Seconds), JSON.stringify(data[i].Name).replace(/['"]+/g, ''), parseInt(data[i].Year), JSON.stringify(data[i].Doping).replace(/['"]+/g, '')]);
     }

//using predefined scales
const xScale = d3.scaleLinear()
.domain([d3.min(dataset, (d) => (d[4]) -1), d3.max(dataset, (d) => d[4])])
.range([padding, w - padding]);

const yScale = d3.scaleLinear()
.domain([d3.min(dataset, (d) => d[2]/60), d3.max(dataset, (d) => d[2]/60)])
.range([h - padding, padding]);

   const xAxis = d3.axisBottom(xScale);
const yAxis = d3.axisLeft(yScale); 
   
   svg.selectAll("circle")
.data(dataset)
.enter()
.append("circle")
.attr("cx", (d) => xScale(d[4]))
.attr("cy", (d) => yScale(d[2]/60))
.attr("r", 6)
   .attr("class", "dot")
   .attr("data-xvalue", (d) => d[4])
   .attr("data-yvalue", (d) => d[2]/60)
   .style("fill", "blue")
   .append("title")
  .text((d) => "Name: " + d[3] + "\r\nYear: " + d[4] + "\r\Minutes: " + d[2]/60)
   .attr("id", "tooltip")
   .attr("data-xvalue", (d) => d[4])
   .attr("data-yvalue", (d) => d[2]/60);
   
   svg.selectAll("circle")
   .on("mouseover", function(d) {
    d3.select(this).attr("r", 10).style("fill", "red");
  })                  
  .on("mouseout", function(d) {
    d3.select(this).attr("r", 5.5).style("fill", "blue");
  });
   
   svg.selectAll("text")
.data(dataset)
.enter()
.append("text")
.text((d) => (Math.round(d[2]/60) + ", " + d[4]))
.attr("x", (d) => xScale(d[4]))
.attr("y", (d) => yScale((d[2]/60) + 0.1))

svg.append("g")
.attr("transform", "translate(0," + (h - padding) + ")")
.call(xAxis)
   .attr("id", "x-axis");

svg.append("g")
.attr("transform", "translate(60,0)")
.call(yAxis)
   .attr("id", "y-axis");
   
 svg.append("text")
    .attr("id", "x-axis-label")
   .attr("text-anchor", "end")
   .attr("x", w - 20)
   .attr("y", h-padding)
   .text("Year");
   
  svg.append("text")
    .attr("id", "y-axis-label")
   .attr("text-anchor", "end")
   .attr("y", 10)
   .attr("dy", ".75em")
   .attr("transform", "rotate(-90)")
   .text("Timing (in Minutes)");
 });