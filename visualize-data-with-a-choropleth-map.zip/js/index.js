var marginsTRBL = {top: 30, right: 30, bottom: 30, left: 220};
const w = 1200;
const h = 600;
//red, orange, yellow, green
const colors = ['rgb(160, 6, 16)', 'rgb(165, 68, 3)', 'rgb(178, 150, 12)', 'rgb(25, 142, 27)']

const svg = d3.select("body")
.append("svg")
  .attr("width", w + marginsTRBL.left + marginsTRBL.right)
  .attr("height", h + marginsTRBL.top + marginsTRBL.bottom)
.append("g")
  .attr("transform",
        "translate(" + marginsTRBL.left + "," + marginsTRBL.top + ")");

var path = d3.geoPath();
d3.queue()
    .defer(d3.json, "https://raw.githubusercontent.com/no-stack-dub-sack/testable-projects-fcc/master/src/data/choropleth_map/counties.json")
    .defer(d3.json, "https://raw.githubusercontent.com/no-stack-dub-sack/testable-projects-fcc/master/src/data/choropleth_map/for_user_education.json")
    .await(startQuery);

function startQuery(err, us, usedu) {
  //this is to correspond the bachelors or higher value with the state ID
  var stateID = {};
  usedu.forEach(function(d) {
    stateID[d.fips] = +d.bachelorsOrHigher;
  });
 
  //this sets the range for the colors
  var colorScale = d3.scaleThreshold()
    .domain([7, 20, 30, 40, 50])
    .range(['rgb(160, 6, 16)', 'rgb(6, 79, 102)', 'rgb(226, 115, 22)', 'rgb(25, 142, 27)', 'rgb(173, 25, 183)']);
   
  svg.append("g")
      .attr("class", "county")
    .selectAll("path")
      .data(topojson.feature(us, us.objects.counties).features)
    .enter().append("path")
      .attr("d", path)
      .style("fill", function(d) {
		      return colorScale(stateID[d.id]); 
	  })
  .style("stroke", "black")
  .append("title")
  .text((d) => "State ID: " + d.id + "\r\nBachelors or Higher: " + stateID[d.id])
  .attr("id", "tooltip");
  
   //creating the legend
   var computedDiff = ["0 - 6", "7 - 19", "20 - 29", "30 - 39", "40 and Above"];
  var val = [6, 19, 29, 39, 49];
  var legend = d3.select("#legend").append("svg")
    .attr("class", "legend")
    .attr("width", 140)
    .attr("height", 200)
    .selectAll("g")
    .data(val)
    .enter()
    .append("g")
    .attr("transform", function(d, i) {
      return "translate(0," + i * 20 + ")";
    });

  legend.append("rect")
    .attr("width", 18)
    .attr("height", 18)
    .style("fill", colorScale);

  legend.append("text")
    .data(computedDiff)
    .attr("x", 24)
    .attr("y", 9)
    .attr("dy", ".35em")
    .text(function(d) {
      return d;
    });
}