var marginsTRBL = {top: 30, right: 30, bottom: 30, left: 30};
const w = 1300;
const h = 450;
const padding = 60;
const colors = ['rgb(48, 73, 46)', 'rgb(148, 150, 39)', 'rgb(244, 158, 66)', 'rgb(244, 65, 65)', 'rgb(173, 25, 183)', 'rgb(12, 0, 12)' ,'rgb(112, 24, 117)', 'rgb(12, 165, 9)', 'rgb(16, 150, 141)', 'rgb(19, 61, 107)', 'rgb(66, 16, 117)', 'rgb(82, 93, 140)', 'rgb(109, 140, 79)', 'rgb(79, 68, 119)', 'rgb(147, 88, 150)', 'rgb(173, 34, 152)', 'rgb(76, 61, 0)', 'rgb(84, 82, 74)', 'rgb(120, 137, 99)']
var categories = [];

function kickstarter() {
  document.getElementById("description").innerHTML = "Top Kickstarter Campaigns Grouped";
  d3.selectAll("rect").remove();
  d3.selectAll("text").remove();
  d3.selectAll("svg").remove();
  d3.selectAll("g").remove();
  
  const svg = d3.select("body")
.append("svg")
  .attr("width", w + marginsTRBL.left + marginsTRBL.right)
  .attr("height", h + marginsTRBL.top + marginsTRBL.bottom)
.append("g")
  .attr("transform",
        "translate(" + marginsTRBL.left + "," + marginsTRBL.top + ")");
d3.json("https://cdn.rawgit.com/freeCodeCamp/testable-projects-fcc/a80ce8f9/src/data/tree_map/kickstarter-funding-data.json", function(data) {
  //console.log(data.children[0].name);
  categories.length = 0;
  for(var i=0; i<data.children.length; i++) {
    //console.log(data.children.length + data.children[i].name);
    categories.push(data.children[i].name);
  }
  
  var baseline = d3.hierarchy(data).sum(function(d){ return d.value}) 
  d3.treemap()
    .size([w, h])
    .padding(2)
    (baseline)

  svg
    .selectAll("rect")
    .data(baseline.leaves())
    .enter()
    .append("rect")
      .attr('x', function (d) { return d.x0; })
      .attr('y', function (d) { return d.y0; })
      .attr('width', function (d) { return d.x1 - d.x0; })
      .attr('height', function (d) { return d.y1 - d.y0; })
      .attr("class", "tile")
      .style("stroke", "black")
      .style("fill", function (d) {
      if(d.data.category == "Product Design") {
        return colors[0];
      }
      else if(d.data.category == "Tabletop Games") {
        return colors[1];
      }
      else if(d.data.category == "Gaming Hardware") {
        return colors[2];
      }
      else if(d.data.category == "Video Games") {
        return colors[3];
      }
      else if(d.data.category == "Sound") {
        return colors[4];
      }
      else if(d.data.category == "Television") {
        return colors[5];
      }
      else if(d.data.category == "Narrative Film") {
        return colors[6];
      }
      else if(d.data.category == "Web") {
        return colors[7];
      }
     else if(d.data.category == "Hardware") {
        return colors[8];
      }
    else if(d.data.category == "Games") {
        return colors[9];
      }
    else if(d.data.category == "3D Printing") {
        return colors[10];
      }
    else if(d.data.category == "Technology") {
        return colors[11];
      }
     else if(d.data.category == "Wearables") {
        return colors[12];
      }
    else if(d.data.category == "Sculpture") {
        return colors[13];
      }
     else if(d.data.category == "Apparel") {
        return colors[14];
      }
    else if(d.data.category == "Food") {
        return colors[15];
      }
    else if(d.data.category == "Art") {
        return colors[16];
      }
     else if(d.data.category == "Gadgets") {
        return colors[17];
      }
     else if(d.data.category == "Drinks") {
        return colors[18];
      }
    })
    .attr("data-name", function (d) {return d.data.name})
    .attr("data-category", function (d){return d.data.category})
    .attr("data-value", function (d) {return d.data.value})
    .append("title")
      .text((d) => "Name: " + d.data.name + "\r\nCategory: " + d.data.category + "\r\nValue: " + d.data.value)
      .attr("id", "tooltip")
  .attr("data-value", function (d) {return d.data.value});
  
  svg
    .selectAll("text")
    .data(baseline.leaves())
    .enter()
    .append("text")
      .attr("x", function(d){ return d.x0+5}) 
      .attr("y", function(d){ return d.y0+20})
      .text(function(d){ 
    if(d.data.name.length > 5)
         return d.data.name.substring(0,8)+'...';
     else
         return d.data.name; })
      .attr("font-size", "10px")
      .attr("fill", "white")
      .attr("max-width", "100px");
  
  //creating the legend
  var n = categories.length/2;
var itemWidth =155;
var itemHeight = 18;
  var ssvg = d3.select("body")
  .append("svg")
  .attr("width", w + marginsTRBL.left + marginsTRBL.right + 300)
  .attr("height", h + marginsTRBL.top + marginsTRBL.bottom);
  
 var legend = ssvg.selectAll(".legend")
	.data(categories)
	.enter()
	.append("g")
	.attr("transform", function(d,i) { return "translate(" + i%n * itemWidth + "," + Math.floor(i/n) * itemHeight + ")"; })
	.attr("class","legend");
	
var rects = legend.append('rect')
	.attr("width",15)
	.attr("height",15)
	.attr("fill", function (d) {
      if(d == "Product Design") {
        return colors[0];
      }
      else if(d == "Tabletop Games") {
        return colors[1];
      }
      else if(d == "Gaming Hardware") {
        return colors[2];
      }
      else if(d == "Video Games") {
        return colors[3];
      }
      else if(d == "Sound") {
        return colors[4];
      }
      else if(d == "Television") {
        return colors[5];
      }
      else if(d == "Narrative Film") {
        return colors[6];
      }
      else if(d == "Web") {
        return colors[7];
      }
     else if(d == "Hardware") {
        return colors[8];
      }
    else if(d == "Games") {
        return colors[9];
      }
    else if(d == "3D Printing") {
        return colors[10];
      }
    else if(d == "Technology") {
        return colors[11];
      }
     else if(d == "Wearables") {
        return colors[12];
      }
    else if(d == "Sculpture") {
        return colors[13];
      }
     else if(d == "Apparel") {
        return colors[14];
      }
    else if(d == "Food") {
        return colors[15];
      }
    else if(d == "Art") {
        return colors[16];
      }
     else if(d == "Gadgets") {
        return colors[17];
      }
     else if(d == "Drinks") {
        return colors[18];
      }
  })
.attr("class", "legend-item");
	
var text = legend.append('text')
	.attr("x", 15)
	.attr("y",12)
	.text(function(d) { return d; });
});
}

function movie() {
  document.getElementById("description").innerHTML = "Top Movie Sales Grouped";
  d3.selectAll("rect").remove();
  d3.selectAll("text").remove();
  d3.selectAll("svg").remove();
  d3.selectAll("g").remove();
  
  const svg = d3.select("body")
.append("svg")
  .attr("width", w + marginsTRBL.left + marginsTRBL.right)
  .attr("height", h + marginsTRBL.top + marginsTRBL.bottom)
.append("g")
  .attr("transform",
        "translate(" + marginsTRBL.left + "," + marginsTRBL.top + ")");
d3.json("https://cdn.rawgit.com/freeCodeCamp/testable-projects-fcc/a80ce8f9/src/data/tree_map/movie-data.json", function(data) {
  //console.log(data.children[0].name);
  categories.length = 0;
  for(var i=0; i<data.children.length; i++) {
    //console.log(data.children.length + data.children[i].name);
    categories.push(data.children[i].name);
  }
  var baseline = d3.hierarchy(data).sum(function(d){ return d.value}) 
  d3.treemap()
    .size([w, h])
    .padding(2)
    (baseline)

  svg
    .selectAll("rect")
    .data(baseline.leaves())
    .enter()
    .append("rect")
      .attr('x', function (d) { return d.x0; })
      .attr('y', function (d) { return d.y0; })
      .attr('width', function (d) { return d.x1 - d.x0; })
      .attr('height', function (d) { return d.y1 - d.y0; })
      .attr("class", "tile")
      .style("stroke", "black")
      .style("fill", function (d) {
      if(d.data.category == "Action") {
        return colors[0];
      }
      else if(d.data.category == "Drama") {
        return colors[1];
      }
      else if(d.data.category == "Adventure") {
        return colors[2];
      }
      else if(d.data.category == "Family") {
        return colors[3];
      }
      else if(d.data.category == "Animation") {
        return colors[4];
      }
      else if(d.data.category == "Television") {
        return colors[5];
      }
      else if(d.data.category == "Comedy") {
        return colors[6];
      }
      else if(d.data.category == "Biography") {
        return colors[7];
      }
    })
    .attr("data-name", function (d) {return d.data.name})
    .attr("data-category", function (d){return d.data.category})
    .attr("data-value", function (d) {return d.data.value})
    .append("title")
      .text((d) => "Name: " + d.data.name + "\r\nCategory: " + d.data.category + "\r\nValue: " + d.data.value)
      .attr("id", "tooltip")
  .attr("data-value", function (d) {return d.data.value});
  
  svg
    .selectAll("text")
    .data(baseline.leaves())
    .enter()
    .append("text")
      .attr("x", function(d){ return d.x0+5}) 
      .attr("y", function(d){ return d.y0+20})
      .text(function(d){ 
    if(d.data.name.length > 5)
         return d.data.name.substring(0,8)+'...';
     else
         return d.data.name; })
      .attr("font-size", "10px")
      .attr("fill", "white");
  
   //creating the legend
  var n = categories.length/2;
var itemWidth =155;
var itemHeight = 18;
  var ssvg = d3.select("body")
  .append("svg")
  .attr("width", w + marginsTRBL.left + marginsTRBL.right + 300)
  .attr("height", h + marginsTRBL.top + marginsTRBL.bottom);
  
 var legend = ssvg.selectAll(".legend")
	.data(categories)
	.enter()
	.append("g")
	.attr("transform", function(d,i) { return "translate(" + i%n * itemWidth + "," + Math.floor(i/n) * itemHeight + ")"; })
	.attr("class","legend");
	
var rects = legend.append('rect')
	.attr("width",15)
	.attr("height",15)
	.attr("fill", function (d) {
      if(d == "Action") {
        return colors[0];
      }
      else if(d == "Drama") {
        return colors[1];
      }
      else if(d == "Adventure") {
        return colors[2];
      }
      else if(d == "Family") {
        return colors[3];
      }
      else if(d == "Animation") {
        return colors[4];
      }
      else if(d == "Television") {
        return colors[5];
      }
      else if(d == "Comedy") {
        return colors[6];
      }
      else if(d == "Biography") {
        return colors[7];
      }
  })
.attr("class", "legend-item");
	
var text = legend.append('text')
	.attr("x", 15)
	.attr("y",12)
	.text(function(d) { return d; });
});
}

function videogame() {
  document.getElementById("description").innerHTML = "Top Video Game Sales Grouped";
 d3.selectAll("rect").remove();
  d3.selectAll("text").remove();
  d3.selectAll("svg").remove();
  d3.selectAll("g").remove();
  
  const svg = d3.select("body")
.append("svg")
  .attr("width", w + marginsTRBL.left + marginsTRBL.right)
  .attr("height", h + marginsTRBL.top + marginsTRBL.bottom)
.append("g")
  .attr("transform",
        "translate(" + marginsTRBL.left + "," + marginsTRBL.top + ")");
d3.json("https://cdn.rawgit.com/freeCodeCamp/testable-projects-fcc/a80ce8f9/src/data/tree_map/video-game-sales-data.json", function(data) {
  //console.log(data.children[0].name);
  categories.length = 0;
  for(var i=0; i<data.children.length; i++) {
    //console.log(data.children.length + data.children[i].name);
    categories.push(data.children[i].name);
  }
  var baseline = d3.hierarchy(data).sum(function(d){ return d.value}) 
  d3.treemap()
    .size([w, h])
    .padding(2)
    (baseline)

  svg
    .selectAll("rect")
    .data(baseline.leaves())
    .enter()
    .append("rect")
      .attr('x', function (d) { return d.x0; })
      .attr('y', function (d) { return d.y0; })
      .attr('width', function (d) { return d.x1 - d.x0; })
      .attr('height', function (d) { return d.y1 - d.y0; })
      .attr("class", "tile")
      .style("stroke", "black")
      .style("fill", function (d) {
      if(d.data.category == "2600") {
        return colors[0];
      }
      else if(d.data.category == "Wii") {
        return colors[1];
      }
      else if(d.data.category == "NES") {
        return colors[2];
      }
      else if(d.data.category == "GB") {
        return colors[3];
      }
      else if(d.data.category == "DS") {
        return colors[4];
      }
      else if(d.data.category == "X360") {
        return colors[5];
      }
      else if(d.data.category == "PS3") {
        return colors[6];
      }
      else if(d.data.category == "PS2") {
        return colors[7];
      }
     else if(d.data.category == "SNES") {
        return colors[8];
      }
    else if(d.data.category == "GBA") {
        return colors[9];
      }
    else if(d.data.category == "PS4") {
        return colors[10];
      }
    else if(d.data.category == "3DS") {
        return colors[11];
      }
     else if(d.data.category == "N64") {
        return colors[12];
      }
    else if(d.data.category == "PS") {
        return colors[13];
      }
     else if(d.data.category == "XB") {
        return colors[14];
      }
    else if(d.data.category == "PC") {
        return colors[15];
      }
    else if(d.data.category == "PSP") {
        return colors[16];
      }
     else if(d.data.category == "XOne") {
        return colors[17];
      }
    })
    .attr("data-name", function (d) {return d.data.name})
    .attr("data-category", function (d){return d.data.category})
    .attr("data-value", function (d) {return d.data.value})
    .append("title")
      .text((d) => "Name: " + d.data.name + "\r\nCategory: " + d.data.category + "\r\nValue: " + d.data.value)
      .attr("id", "tooltip")
  .attr("data-value", function (d) {return d.data.value});
  
  svg
    .selectAll("text")
    .data(baseline.leaves())
    .enter()
    .append("text")
      .attr("x", function(d){ return d.x0+5}) 
      .attr("y", function(d){ return d.y0+20})
      .text(function(d){ 
    if(d.data.name.length > 5)
         return d.data.name.substring(0,8)+'...';
     else
         return d.data.name; })
      .attr("font-size", "10px")
      .attr("fill", "white");
  
  //creating the legend
  var n = categories.length/2;
var itemWidth =155;
var itemHeight = 18;
  var ssvg = d3.select("body")
  .append("svg")
  .attr("width", w + marginsTRBL.left + marginsTRBL.right + 300)
  .attr("height", h + marginsTRBL.top + marginsTRBL.bottom);
  
 var legend = ssvg.selectAll(".legend")
	.data(categories)
	.enter()
	.append("g")
	.attr("transform", function(d,i) { return "translate(" + i%n * itemWidth + "," + Math.floor(i/n) * itemHeight + ")"; })
	.attr("class","legend");
	
var rects = legend.append('rect')
	.attr("width",15)
	.attr("height",15)
	.attr("fill", function (d) {
      if(d == "2600") {
        return colors[0];
      }
      else if(d == "Wii") {
        return colors[1];
      }
      else if(d == "NES") {
        return colors[2];
      }
      else if(d == "GB") {
        return colors[3];
      }
      else if(d == "DS") {
        return colors[4];
      }
      else if(d == "X360") {
        return colors[5];
      }
      else if(d == "PS3") {
        return colors[6];
      }
      else if(d == "PS2") {
        return colors[7];
      }
     else if(d == "SNES") {
        return colors[8];
      }
    else if(d == "GBA") {
        return colors[9];
      }
    else if(d == "PS4") {
        return colors[10];
      }
    else if(d == "3DS") {
        return colors[11];
      }
     else if(d == "N64") {
        return colors[12];
      }
    else if(d == "PS") {
        return colors[13];
      }
     else if(d == "XB") {
        return colors[14];
      }
    else if(d == "PC") {
        return colors[15];
      }
    else if(d == "PSP") {
        return colors[16];
      }
     else if(d == "XOne") {
        return colors[17];
      }
  })
.attr("class", "legend-item");
	
var text = legend.append('text')
	.attr("x", 15)
	.attr("y",12)
	.text(function(d) { return d; });
});
}